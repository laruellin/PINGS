git checkout  e5086a96da751f73dd6f3ae2af5fd46a3e1ef50a 
python3 ./pings.py ./config/run_kitti_gs.yaml kitti 06 -i ./data/ --range 0 1101 1 --seed 42 --log-on --tag 4090_gs_on_mid_s06